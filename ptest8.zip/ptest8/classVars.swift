//
//  classVars.swift
//  ptest8
//
//  Created by Phillip Brisco on 7/22/16.
//  Copyright © 2016 Phillip  Brisco. All rights reserved.
//

import Foundation
import UIKit

var storedResults = [AnyObject]()
var selectedItem: String?
let tableContent = UITableViewController()
var superLabelArr = [UILabel]()
let itemArr = ["Id:   ","Name:   ","Username:   ","Email:   ","Street:   ","Suite:   ","City:   ","Zip:   ","Latitude:   ","Longitude:   ","Phone:   ","Website:   ","Company:   ","Phrase:   ","BS:   "]
let theLabel = UILabel() // This is a class variable so we can easil remove a created label
var itemCounter = 0

var idArr = [Int32]()
var nameArr = [String]()
var usernameArr = [String]()
var emailArr = [String]()
var streetArr = [String]()
var suiteArr = [String]()
var cityArr = [String]()
var zipCodeArr = [String]()
var latArr = [String]()
var lngArr = [String]()
var phoneArr = [String]()
var websiteArr = [String]()
var companyNameArr = [String]()
var companyPhraseArr = [String]()
var companyBSArr = [String]()
    