//
//  BackingStore+CoreDataProperties.swift
//  ptest8
//
//  Created by Phillip Brisco on 7/21/16.
//  Copyright © 2016 Phillip  Brisco. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

import Foundation
import CoreData

extension BackingStore {

    @NSManaged var id: String?
    @NSManaged var name: String?
    @NSManaged var username: String?
    @NSManaged var email: String?
    @NSManaged var street: String?
    @NSManaged var suite: String?
    @NSManaged var city: String?
    @NSManaged var zip: String?
    @NSManaged var lat: String?
    @NSManaged var lng: String?
    @NSManaged var phone: String?
    @NSManaged var website: String?
    @NSManaged var compName: String?
    @NSManaged var compPhrase: String?
    @NSManaged var compBS: String?

}
