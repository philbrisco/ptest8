//
//  BackingStore.swift
//  ptest8
//
//  Created by Phillip Brisco on 7/21/16.
//  Copyright © 2016 Phillip  Brisco. All rights reserved.
//

import Foundation
import CoreData


class BackingStore: NSManagedObject {

// Insert code here to add functionality to your managed object subclass

}
