//
//  ViewController.swift
//  ptest8
//
//  Created by Phillip Brisco on 7/21/16.
//  Copyright © 2016 Phillip  Brisco. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController, UIPopoverPresentationControllerDelegate, UITableViewDelegate, UITableViewDataSource {
    let managedObjectContext = (UIApplication.sharedApplication().delegate as! AppDelegate).managedObjectContext
    
    override func viewDidLoad() {
        super.viewDidLoad()
        var storedRowCount = 0
        storedRowCount = findStuff() // Find out if backing store is empty
        superLabelArr.removeAll()
        
        // Create labels on the screen to display detail data
        for i in 0..<15 {
            let tmpLabel = UILabel()
            let theWidth = UIScreen.mainScreen().bounds.width
            let theHeight = UIScreen.mainScreen().bounds.height
            tmpLabel.textColor = UIColor.whiteColor()
            tmpLabel.adjustsFontSizeToFitWidth = true
            tmpLabel.frame = CGRectMake(theWidth/2 - 150,theHeight/2 - theHeight/4 + CGFloat(i) * 30, 300, 25)
            tmpLabel.textAlignment = NSTextAlignment.Center
            superLabelArr.append(tmpLabel)
            self.view.addSubview(superLabelArr[i])
        }
        
        // If there is no data in backingStore, then we go out to the Internet to get it.
        // The swiftyJSON library is being used to simplify the parsing of json data.
        if (storedRowCount == 0) {
            let urlString = "http://jsonplaceholder.typicode.com/users"
            if let url = NSURL(string: urlString) {
            
                if let data = try? NSData(contentsOfURL: url, options: []) {
                    globArrInit()
                    
                    let json = JSON(data: data)
                    var JSCount = 0
                    for _ in json  {
                        let newItem = NSEntityDescription.insertNewObjectForEntityForName("BackingStore", inManagedObjectContext: self.managedObjectContext) as! BackingStore
                        
                        // Put parsed json data into the appropriate global arrays.
                        idArr.append(json[JSCount]["id"].int32!)
                        nameArr.append(json[JSCount]["name"].stringValue)
                        usernameArr.append(json[JSCount]["username"].stringValue)
                        emailArr.append(json[JSCount]["email"].stringValue)
                        streetArr.append(json[JSCount]["address"]["street"].stringValue)
                        suiteArr.append(json[JSCount]["address"]["suite"].stringValue)
                        cityArr.append(json[JSCount]["address"]["city"].stringValue)
                        zipCodeArr.append(json[JSCount]["address"]["zipcode"].stringValue)
                        latArr.append(json[JSCount]["address"]["geo"]["lat"].stringValue)
                        lngArr.append(json[JSCount]["address"]["geo"]["lng"].stringValue)
                        phoneArr.append(json[JSCount]["phone"].stringValue)
                        websiteArr.append(json[JSCount]["website"].stringValue)
                        companyNameArr.append(json[JSCount]["company"]["name"].stringValue)
                        companyPhraseArr.append(json[JSCount]["company"]["catchPhrase"].stringValue)
                        companyBSArr.append(json[JSCount]["company"]["bs"].stringValue)
                                            newItem.id = String(idArr[JSCount])
                        
                        // Add the data to the backing store.
                        newItem.name = nameArr[JSCount]
                        newItem.username = usernameArr[JSCount]
                        newItem.street = streetArr[JSCount]
                        newItem.suite = suiteArr[JSCount]
                        newItem.city = cityArr[JSCount]
                        newItem.zip = zipCodeArr[JSCount]
                        newItem.email = emailArr[JSCount]
                        newItem.phone = phoneArr[JSCount]
                        newItem.website = websiteArr[JSCount]
                        newItem.lat = latArr[JSCount]
                        newItem.lng = lngArr[JSCount]
                        newItem.compName = companyNameArr[JSCount]
                        newItem.compPhrase = companyPhraseArr[JSCount]
                        newItem.compBS = companyBSArr[JSCount]
                        
                        JSCount += 1
                    }
                
                }
            }
            
        }

        // Add the plus sign as a button on the navigation bar
        navigationItem.rightBarButtonItem = UIBarButtonItem(
            barButtonSystemItem: .Add,
            target: self,
            action: #selector(ViewController.performAdd(_:)))
    }


    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        itemCounter = 0
        return 10
    }
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // Return the number of sections.
        return 1
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        var cell: UITableViewCell? = tableView.dequeueReusableCellWithIdentifier("CELL")! as UITableViewCell
        
        
        if cell == nil {
            cell = UITableViewCell(style: UITableViewCellStyle.Value1, reuseIdentifier: "CELL")
        }
        
        if itemCounter > 9 {
            itemCounter = 9
        }
        
        cell!.textLabel!.text = nameArr[itemCounter]
        itemCounter += 1
        
        return cell!
    }
    
    // Make sure that our global arrays are empty before we start using them
    func globArrInit () {
        idArr.removeAll()
        nameArr.removeAll()
        usernameArr.removeAll()
        emailArr.removeAll()
        streetArr.removeAll()
        suiteArr.removeAll()
        cityArr.removeAll()
        zipCodeArr.removeAll()
        latArr.removeAll()
        lngArr.removeAll()
        phoneArr.removeAll()
        websiteArr.removeAll()
        companyNameArr.removeAll()
        companyPhraseArr.removeAll()
        companyBSArr.removeAll()
    }
    
    // See if backing store data exists.  If it does, get it.
    func findStuff () -> Int {
        var retVal = 0
        
        let entityDescription =
            NSEntityDescription.entityForName("BackingStore",
                                              inManagedObjectContext: managedObjectContext)
        let request = NSFetchRequest()
        request.entity = entityDescription
        
        do {
            var results =
                try managedObjectContext.executeFetchRequest(request)
            
            retVal = results.count
            
            if results.count > 0 {
                globArrInit()
                
                for index in  0..<results.count {
                    let match = results[index] as! NSManagedObject
        
                    // Append backing store data to the appropriate global arrays
                    idArr.append(Int32(match.valueForKey("id") as! String)!)
                    nameArr.append((match.valueForKey("name") as? String)!)
                    usernameArr.append((match.valueForKey("username") as? String)!)
                    emailArr.append((match.valueForKey("email") as? String)!)
                    streetArr.append((match.valueForKey("street") as? String)!)
                    suiteArr.append((match.valueForKey("suite") as? String)!)
                    cityArr.append((match.valueForKey("city") as? String)!)
                    zipCodeArr.append((match.valueForKey("zip") as? String)!)
                    latArr.append((match.valueForKey("lat") as? String)!)
                    lngArr.append((match.valueForKey("lng") as? String)!)
                    phoneArr.append((match.valueForKey("phone") as? String)!)
                    websiteArr.append((match.valueForKey("website") as? String)!)
                    companyNameArr.append((match.valueForKey("compName") as? String)!)
                    companyPhraseArr.append((match.valueForKey("compPhrase") as? String)!)
                    companyBSArr.append((match.valueForKey("compBS") as? String)!)
                }
                //                status.text = "Matches found: \(results.count)"
            } else {
                //                status.text = "No Match"
            }
            
        } catch _ as NSError {
            //            status.text = error.localizedFailureReason
        }
        
        return retVal
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        tableView.deselectRowAtIndexPath(indexPath, animated: true)
        performHandling(indexPath.row)
        self.dismissViewControllerAnimated(true, completion: nil)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func performAdd(sender: UIBarButtonItem){
        let theWidth = UIScreen.mainScreen().bounds.width
        tableContent.removeFromParentViewController() // Remove old UITableViewController, if it exists
        theLabel.removeFromSuperview() // Remove the previous label,if it exists
        theLabel.textColor = UIColor.redColor()
        theLabel.frame = CGRectMake(theWidth - 30, 60, 5, 5)
        self.view.addSubview(theLabel)
        
        tableContent.modalPresentationStyle = UIModalPresentationStyle.Popover
        tableContent.preferredContentSize = CGSizeMake(200, 450)
        
        let popover = tableContent.popoverPresentationController
        popover?.sourceView = theLabel
        popover?.delegate = self
        tableContent.tableView.delegate = self
        tableContent.tableView.dataSource = self
        tableContent.tableView.scrollEnabled = false
        tableContent.tableView.registerClass(MyTableViewCell.self, forCellReuseIdentifier: "CELL")

        // populateTable(tableContent.tableView)
        presentViewController(tableContent, animated: true, completion: nil)
    }
    
    // Present the popover table in popup format with any device
    func adaptivePresentationStyleForPresentationController(controller: UIPresentationController) -> UIModalPresentationStyle {
        return .None
    }
    
    // Display the detail data for the selected user.
    func performHandling (rowNum: Int)
    {
        superLabelArr[0].text = itemArr[1] + nameArr[rowNum]
        superLabelArr[1].text = itemArr[2] + usernameArr[rowNum]
        superLabelArr[2].text = itemArr[3] + emailArr[rowNum]
        superLabelArr[3].text = itemArr[4] + streetArr[rowNum]
        superLabelArr[4].text = itemArr[5] + suiteArr[rowNum]
        superLabelArr[5].text = itemArr[6] + cityArr[rowNum]
        superLabelArr[6].text = itemArr[7] + zipCodeArr[rowNum]
        superLabelArr[7].text = itemArr[8] + latArr[rowNum]
        superLabelArr[8].text = itemArr[9] + lngArr[rowNum]
        superLabelArr[9].text = itemArr[10] + phoneArr[rowNum]
        superLabelArr[10].text = itemArr[11] + websiteArr[rowNum]
        superLabelArr[11].text = itemArr[12] + companyNameArr[rowNum]
        superLabelArr[12].text = itemArr[13] + companyPhraseArr[rowNum]
        superLabelArr[13].text = itemArr[14] + companyBSArr[rowNum]
    }

}

class MyTableViewCell : UITableViewCell {
    
    override init(style: UITableViewCellStyle, reuseIdentifier: String!) {
        super.init(style: UITableViewCellStyle.Value1, reuseIdentifier: reuseIdentifier)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
